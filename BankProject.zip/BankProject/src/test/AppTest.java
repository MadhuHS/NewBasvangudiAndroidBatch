package test;

import com.icici.account.Account;
import com.icici.account.Bank;
import com.icici.customer.Customer;

public class AppTest 
{
  public static void main(String[] args)
  {
	  Bank b1 = new Bank();
	  Account a1 = b1.createAccount('S',5000);
	  
	  System.out.println(a1);
	  System.out.println(b1.acc1);
	  
	  a1.deposit();
	  a1.withdraw();
	  
	  System.out.println(a1.getBalance());
	  System.out.println(a1.getAcntno());
	  
	  
	  Customer c1 = b1.createCustomer();
	  
	  
	  
	  
	 
  }
}
