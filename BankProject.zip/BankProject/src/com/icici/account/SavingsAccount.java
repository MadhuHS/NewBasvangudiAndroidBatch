package com.icici.account;

public class SavingsAccount extends Account {

	@Override
	public void deposit() 
	{
	  System.out.println("this is deposit() of Savings Account");	
	}

	@Override
	public void withdraw()
	{
	 System.out.println("this is withdraw() of Savings Account");	
	}

}
