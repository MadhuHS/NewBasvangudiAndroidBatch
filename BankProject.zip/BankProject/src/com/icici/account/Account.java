package com.icici.account;

import com.icici.atm.AtmTransactions;

public abstract class Account
{
   private int    acntno = 987654321;
   private double balance;
   AtmTransactions trans;
   private int     custID;
   
   public int getCustID() 
   {
	return custID;
	}

   public void setCustID(int custID) 
   {
	this.custID = custID;
  } 
   
   abstract public void deposit();
   abstract public void withdraw();
   
   public int getAcntno() 
   {
	 return acntno;
   }

public double getBalance() {
	return balance;
}
public void setBalance(double balance) 
{
	//check balance is greater than zero
	this.balance = balance;
}

   public void createTransaction()
   {
	 System.out.println("creating Transaction"); 
	 trans = new AtmTransactions();
   }
   
   
}
