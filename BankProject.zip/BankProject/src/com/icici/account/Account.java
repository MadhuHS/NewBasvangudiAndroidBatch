package com.icici.account;

import com.icici.atm.AtmTransactions;

public abstract class Account
{
   private int    acntno = 7895874;
   private double balance;
   AtmTransactions trans;
   
   abstract public void deposit();
   abstract public void withdraw();
   
   public int getAcntno() 
   {
	 return acntno;
   }

public double getBalance() {
	return balance;
}
public void setBalance(double balance) 
{
	//check balance is greater than zero
	this.balance = balance;
}

   public void createTransaction()
   {
	 System.out.println("creating Transaction"); 
	 trans = new AtmTransactions();
   }
   
   
}
