package com.icici.account;

import java.util.Scanner;

import com.icici.atm.ATM;
import com.icici.customer.Customer;

public class Bank 
{
   int code;
   String address;
	
   public Account[]  acc1 = new Account[5];
   public Customer[] c1   = new Customer[5];
   ATM a1;
   private static Bank b1 = null;
   int count     = 0;
   int custcount = 0;
   int ID = 100;
   
   private Bank()
   {
	   
   }
   
   public static Bank getBankObj()
   {
	   if(b1 == null)
	   {
		   b1 = new Bank();
		   return b1;
	   }
	   
	   return b1;
   }
   
   public void manages()
   {
	   
   }
   
   public void maintains()
   {
	   
   }
   
   public Account createAccount(String type,double bal)
   {
	   
	if(count < acc1.length)
	{
   	  if(type.equals("S"))
   	  {
   	  	acc1[count] = new SavingsAccount();
   	  	acc1[count].setBalance(bal);
   	  	acc1[count].setCustID(ID);
   	  	return acc1[count++];
      }
   	
   	else
   	{
   		acc1[count] = new CurrentAccount();
   	  	acc1[count].setBalance(bal);
   		return acc1[count++];
   	}
 	  	
	}
	
	else
	{
		ArrayIndexOutOfBoundsException ae = new ArrayIndexOutOfBoundsException("Account cannot created...");
		throw ae;
	}
	
   }
   
   public Customer createCustomer()
   {
	   if(custcount < c1.length)
	   {
	    c1[custcount] = new Customer();
	    Scanner sc1 = new Scanner(System.in);

	   System.out.println("Enter type of Account");
	   String type = sc1.nextLine();
	   
	   System.out.println("Enter your Name");
	   String name = sc1.nextLine();
	   
	   System.out.println("Enter your Address");
	   String addrs = sc1.nextLine();
	   
	   System.out.println("Enter your DOB");
	   String dob = sc1.nextLine();
	   
	   System.out.println("Enter the PIN");
	   int pin = sc1.nextInt();
	   
	   System.out.println("Enter your deposit amount");
	   double bal = sc1.nextDouble();
	   
	   createAccount(type, bal);
	   
	   c1[custcount].setName(name);
	   c1[custcount].setAddress(addrs);
	   c1[custcount].setDob(dob);
	   c1[custcount].setPin(pin);
	   c1[custcount].setRef(acc1[count]);
	   c1[custcount].setCustID(ID++);
	   c1[custcount].showCustomerDetails();
	   return c1[custcount];
	   }
	   
	   else
	   {
		 ArrayIndexOutOfBoundsException ae = new ArrayIndexOutOfBoundsException("Account cannot created...");
		 throw ae;
	   }
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
}
