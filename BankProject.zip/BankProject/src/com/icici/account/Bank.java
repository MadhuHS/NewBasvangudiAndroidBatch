package com.icici.account;

import java.util.Scanner;

import com.icici.atm.ATM;
import com.icici.customer.Customer;

public class Bank 
{
   int code;
   String address;
	
   public Account acc1;
   public Customer c1;
   ATM a1;
   private static Bank b1 = null;
   
   private Bank()
   {
	   
   }
   
   public static Bank getBankObj()
   {
	   if(b1 == null)
	   {
		   b1 = new Bank();
		   return b1;
	   }
	   
	   return b1;
   }
   
   public void manages()
   {
	   
   }
   
   public void maintains()
   {
	   
   }
   
   public Account createAccount(String type,double bal)
   {
  
   	if(type.equals("S"))
   	{
   	  	acc1 = new SavingsAccount();
   	  	acc1.setBalance(bal);
   	  	return acc1;
   	}
   	
   	else
   	{
   		acc1 = new CurrentAccount();
   	  	acc1.setBalance(bal);
   		return acc1;
   	}
   	
   }
   
   public Customer createCustomer()
   {
	   c1 = new Customer();
	   Scanner sc1 = new Scanner(System.in);

	   System.out.println("Enter type of Account");
	   String type = sc1.nextLine();
	   
	   System.out.println("Enter your Name");
	   String name = sc1.nextLine();
	   
	   System.out.println("Enter your Address");
	   String addrs = sc1.nextLine();
	   
	   System.out.println("Enter your DOB");
	   String dob = sc1.nextLine();
	   
	   System.out.println("Enter the PIN");
	   int pin = sc1.nextInt();
	   
	   System.out.println("Enter your deposit amount");
	   double bal = sc1.nextDouble();
	   
	   createAccount(type, bal);
	   
	   c1.setName(name);
	   c1.setAddress(addrs);
	   c1.setDob(dob);
	   c1.setPin(pin);
	   c1.setRef(acc1);
	   c1.showCustomerDetails();
	   return c1;
   }
   
   
   
   
   
   
   
   
   
   
   
   
   
}
