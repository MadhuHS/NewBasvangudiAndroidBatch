package com.icici.account;

import java.util.Scanner;

public class CurrentAccount extends Account 
{
	Scanner sc1 = new Scanner(System.in);
	Bank b1     = Bank.getBankObj();
	
	
	@Override
	public void deposit() 
	throws IllegalArgumentException
	{
	   int atempt = 0;
	   
	   for(;;)
	   {
	   
		   System.out.println("Enter the amount for deposit");
	       double amt = sc1.nextDouble();
	   
	   if(amt > 0)
	   {
		   double bal = b1.c1[0].getRef().getBalance();
		   bal = bal + amt;
		   b1.c1[0].getRef().setBalance(bal);  
		   System.out.println("Avilable bal = "+ b1.c1[0].getRef().getBalance());
		   return;
	   }
	   
	   else
	   {
		   System.out.println("invalid amount");
		   atempt++;
	   }
	   
	   if(atempt==3)
	   {
		   IllegalArgumentException exp = 
		   new IllegalArgumentException("Too many tries..try later");
		   throw exp;
	   }
	}
	   
	}

	@Override
	public void withdraw()
	{
	
	}

}
