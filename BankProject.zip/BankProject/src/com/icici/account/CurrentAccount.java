package com.icici.account;

import java.util.Scanner;

public class CurrentAccount extends Account 
{
	Scanner sc1 = new Scanner(System.in);
	Bank b1     = Bank.getBankObj();
	
	@Override
	public void deposit()
	{
	   int atempt = 0;
	   
	   for(;;)
	   {
	   
		   System.out.println("Enter the amount for deposit");
	       double amt = sc1.nextDouble();
	   
	   if(amt > 0)
	   {
		   double bal = b1.acc1.getBalance();
		   bal = bal + amt;
		   b1.acc1.setBalance(bal);  
		   System.out.println("Avilable bal = "+b1.acc1.getBalance());
		   return;
	   }
	   
	   else
	   {
		   System.out.println("invalid amount");
		   atempt++;
	   }
	   
	   if(atempt==3)
	   {
		   System.out.println("Too many tries..try later");
		   System.exit(0);
	   }
	}
	   
	}

	@Override
	public void withdraw()
	{
	
	}

}
