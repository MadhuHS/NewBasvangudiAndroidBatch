package com.icici.ui;

import java.util.Scanner;

import com.icici.account.Bank;

public class Mainclass
{
   public static void main(String[] args)
   {
	   int choice;
	   Bank b1 = Bank.getBankObj(); 
	   
	   for(;;)
	   {
		   System.out.println("Press 1 for Customer Sign up");
		   System.out.println("Press 2 for Withdraw");
		   System.out.println("Press 3 for Deposit");
		   System.out.println("Press 0 for Log out");
		   
		   Scanner sc1 = new Scanner(System.in);
		   choice = sc1.nextInt();
	       switch(choice)
	   {
	      case 0  : System.out.println("Log out...");
	    	        System.exit(0);
                    
	      case 1  : b1.createCustomer();
	    	        break;
	    	        
	      case 2  : b1.acc1.withdraw();
	                break;
	                
	      case 3  : b1.acc1.deposit();
	                break;
	     default : System.out.println("invalid choice");
	   }
	   }
	   
	   
   }
}








