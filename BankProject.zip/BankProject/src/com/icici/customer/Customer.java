package com.icici.customer;

import com.icici.account.Account;

public class Customer 
{
  private Account ref;
  private String name;
  private String address;
  private String dob;
  private long   cardno = 1234567890;
  private int    pin;
  private int    custID = 100; 
  

  public int getCustID()
  {
	return custID;
  }

public void setCustID(int custID)
{
	this.custID = custID;
}

public Account getRef()
  {
	return ref;
  }

public void setRef(Account ref)
{
	this.ref = ref;
}

public String getName() 
  {
	return name;
  }

public void setName(String name)
{
	this.name = name;
}

public String getAddress()
{
	return address;
}

public void setAddress(String address) 
{
	this.address = address;
}

public String getDob() 
{
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

public long getCardno() 
{
	return cardno;
}

public int getPin()
{
	return pin;
}

public void setPin(int pin) 
{
	this.pin = pin;
}

  public void verifyPassword()
  {
	  
  }
  
  public void showCustomerDetails()
  {
	  System.out.println("----------Account Created-------------");
	  
	  System.out.println("Name        : "+name);
	  System.out.println("Address     : "+address);
	  System.out.println("DOB         : "+dob);
	  System.out.println("CardNo      : "+cardno);
	  System.out.println("PIN         : "+pin);
	  System.out.println("Customer ID : "+custID);
	  
	  System.out.println("Account number  : "+ref.getAcntno());
	  System.out.println("Account balance : "+ref.getBalance());
	  
	  System.out.println("----------Account Created-------------");

  }
  
   @Override
	public String toString()
    {
		String info = "Name : "+name+" Acntno : "+ref.getAcntno();
		return info;
	}
  

  
}
