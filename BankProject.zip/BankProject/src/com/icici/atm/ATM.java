package com.icici.atm;

public class ATM 
{
   String loaction;
   String managedby;
   
   public void identifies()
   {
	   
   }
   
   public void transactions()
   {
	   
   }
}
