package com.icici.atm;

public class AtmTransactions 
{
   long   transID;
   String date;
   String type;
   double amount;
   double postbalance;
   
   public void modifies()
   {
	   
   }
}
